# A program that reads numbers from a file
# 07/05/17
# CTI-110 M6T1 - File Display
# India Sylvester
#

def main():
    #Open the file.
    myfile = open('number.txt','r')

    #Read and display the file's contents.
    for line in myfile:
        number = int(line)
        print(number)

    #close the file.
    myfile.close()
main()
