# A program that reads the numbers that were written to randomNumbers.txt
# 7/10/17
# CTI-110 M6HW2 - Random Number File Reader
# India
#

#define the main 
def main():

    #open the file
    myfile = open('randomNumbers.txt', 'r')

    #intialize total
    total = 0

    #Intialize count
    count = 0

    #get values from each line
    for line in myfile:

        #converting lines to int
        randNum = int(line)

        #add 1 to count
        count += 1

        #display the numbers
        print( count, ': ', randNum)

        #sum it up
        total += randNum

    #Close file
    myfile.close()

    #print out the total
    print("Total of these numbers is: ", total)

    #print the number of numbers
    print("The number of numbers that were read from this file were: ", count)

#call the main
main()
