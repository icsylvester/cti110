# A program that writes the file with a user input of how many line
# 07/05/17
# CTI-110 M6HW1 - Random Number File Writer
# India Sylvester


#Import random
import random

#define main function
def main():
    
    #Create the file
    myfile = open('randomNumbers.txt', 'w')

    #get how much number the file should hold
    numrange = int(input("How many numbers should the file hold?: "))

    #a loop for 500 numbers
    for i in range (1,numrange+1):

        #initialize the numbers
        number = random.randint(1,500)

        #start new line
        myfile.write(str(number) + "\n")

#call the main
main()
